import sys
import json
import os.path
import copy
import time
import threading
import ssl
import ntplib
import datetime
from threading import Timer
from base64 import b64encode, b64decode
from hashlib import sha256
from hmac import HMAC
import inspect

if sys.version_info >= (3, 5):
    import http.client as httplib
    import urllib.request as urllib
    from urllib.parse import urlparse,quote_plus,urlencode

else:
    import httplib
    from urllib import quote_plus,urlencode
    import urllib2 as urllib
    from urlparse import urlparse

from iotconnect.client.mqttclient import mqttclient
from iotconnect.client.httpclient import httpclient
from iotconnect.client.offlineclient import offlineclient
from iotconnect.client.fileuploadclient import FileUploadClient

from iotconnect.common.data_evaluation import data_evaluation
from iotconnect.common.rule_evaluation import rule_evaluation

from iotconnect.common.infinite_timer import infinite_timer

from iotconnect.common.util import util

from iotconnect.IoTConnectSDKException import IoTConnectSDKException

from iotconnect.client.awskinesisclient import get_kinesis_cer, start_gstreamer, stop_gstreamer, start_kvs_webrtc_from_devicecert

MSGTYPE = {
    "RPT": 0,
    "FLT": 1,
    "RPTEDGE": 2,
    "RMEdge": 3,
    "LOG" : 4,
    "ACK" : 5,
    "OTA" : 6,
    "FIRMWARE": 11,
    "FILE": 11
}
ErorCode = {
    "OK": 0,
    "DEV_NOT_REG": 1,
    "AUTO_REG": 2,
    "DEV_NOT_FOUND": 3,
    "DEV_INACTIVE": 4,
    "OBJ_MOVED": 5,
    "CPID_NOT_FOUND": 6
}
CMDTYPE = {
    "DCOMM": 0,
    "FIRMWARE": 1,
    "MODULE":2,
    "U_ATTRIBUTE": 101,
    "U_SETTING": 102,
    "U_RULE": 103,
    "U_DEVICE": 104,
    "DATA_FRQ": 105,
    "U_barred":106,
    "D_Disabled":107,
    "D_Released":108,
    "STOP":109,
    "Start_Hr_beat":110,
    "Stop_Hr_beat":111,
    "stream_start": 112,
    "stream_stop": 113,
    "is_connect": 116,
    "SYNC": "sync",
    "RESETPWD": "resetpwd",
    "UCART": "updatecrt"
}
OPTION = {
    "attribute": "att",
    "setting": "set",
    "protocol": "p",
    "device": "d",
    "sdkConfig": "sc",
    "rule": "r"
}

class IoTConnectSDK:
    _property=None
    _config = None
    _cpId = None
    _env = None
    _sId =None
    _uniqueId = None
    pf = None
    _listner_callback = None
    _listner_ota_callback = None
    _listner_device_callback = None
    _listner_attchng_callback = None
    _listner_module_callback = None
    _listner_devicechng_callback = None
    _listner_rulechng_callback = None
    _listner_creatchild_callback=None
    _listner_twin_callback = None
    _onReady = None
    _data_json = None
    _client = None
    _is_process_started = False
    _base_url = ""
    _thread = None
    _ruleEval = None
    _offlineClient = None
    _lock = None
    _dispose = False
    _live_device=[]
    _debug=False
    _data_frequency = 60
    _debug_error_path=None
    _debug_output_path=None
    _dftime=None
    _offlineflag = False
    _time_s=None
    _heartbeat_timer = None
    deletechild=None
    _listner_deletechild_callback = None
    _validation = True
    _getattribute_callback = None
    _listner_direct_callback_list = {}
    _aws_credential_endpoint_URL = ""
    _kinesis_stream_as = True
    _kinesis_stream_carn = ""
    _kinesis_stream_status = False
    _file_upload_client = None
    _fs_config = None

    def get_config(self):
        try:
            self._config = None
            _path = os.path.abspath(os.path.dirname(__file__))
            _config_path = os.path.join(_path, "assets/config.json")
            with open(_config_path) as config_file:
                self._config = json.loads(config_file.read())
            if not self.get_properties():
                raise(IoTConnectSDKException("01", "Config file"))

        except:
            raise(IoTConnectSDKException("01", "Config file"))

    def getTwins(self):
        if self._dispose == True:
            raise(IoTConnectSDKException("00", "you are not able to call this function"))
        if self._is_process_started == False:
            return
        if self._client:
            self._client.get_twin()

    def get_properties(self):
        try:
            _properties = self._property
            if _properties != None:
                for prop in _properties:
                    if _properties[prop]:
                        self._config[prop] = _properties[prop]
                    else:
                        self._config[prop] = None
                    if prop == 'IsDebug' and _properties[prop] == True:
                        self._debug=True
            return True
        except Exception as ex:
            return False

    def reconnect_device(self,msg):
        try:
            self.print_debuglog(msg,0)

            if(self._kinesis_stream_status == True):
                stop_gstreamer()
                print("Video_Stream_Task : Streaming Stopped")
                self._kinesis_stream_status = False
            
            # self.process_sync("all")
        except:
            self._offlineflag = True

    def get_base_url(self):
        try:
            if self.is_not_blank(self._sId):
                base_url = "/api/v2.1/dsdk/sid/" + self._sId + "?pf=" + self.pf
            else:
                base_url = "/api/v2.1/dsdk/cpid/" + self._cpId +"/env/" + self._env + "?pf=" + self.pf
            
            base_url = self._property["discoveryUrl"] + base_url
            res = urllib.urlopen(base_url).read().decode("utf-8")
            data = json.loads(res)
            a = (data['d'].keys())
            if 'pf' in a:
                return data['d']["bu"], data['d']["pf"]
            else:
                pf = 'aws'
                return data['d']["bu"], pf  
            
        except Exception as ex:
            self.print_debuglog(ex.message, 1)
            return None

    def generate_sas_token(self,uri, key, policy_name=None, expiry=31536000):
        ttl = time.time() + expiry
        sign_key = "%s\n%d" % ((quote_plus(uri)), int(ttl))
        signature = b64encode(HMAC(b64decode(key), sign_key.encode('utf-8'), sha256).digest())
        rawtoken = {
            'sr' :  uri,
            'sig': signature,
            'se' : str(int(ttl))
        }
        if policy_name is not None:
            rawtoken['skn'] = policy_name
        return 'SharedAccessSignature ' + urlencode(rawtoken)

    def post_call(self, url):
        try:
            url=url+"/uid/"+self._uniqueId
            res = urllib.urlopen(url).read().decode("utf-8")
            data = json.loads(res)
            return data
        except:
            return None

    def UploadImage(self, file_path=None, file_stream=None, file_name=None):
        """
        Upload an image file to S3 and publish to MQTT

        Args:
            file_path: Path to the file (if uploading from file system)
            file_stream: File content as bytes or base64 string (if uploading from memory)
            file_name: Name of file (required if using file_stream)

        Returns:
            dict: Upload result with keys:
                - success: bool
                - s3_key: S3 object key
                - bucket: Bucket name
                - url: URL path for MQTT message
                - mqtt_published: bool indicating if MQTT message was sent
                - error: Error message (if failed)
        """
        try:
            if self._dispose == True:
                raise(IoTConnectSDKException("00", "you are not able to call this function"))

            if not self._file_upload_client:
                return {
                    "success": False,
                    "s3_key": None,
                    "bucket": None,
                    "url": None,
                    "mqtt_published": False,
                    "error": "File upload client not initialized. Check if fs configuration is available in sync response."
                }

            if self._is_process_started == False:
                return {
                    "success": False,
                    "s3_key": None,
                    "bucket": None,
                    "url": None,
                    "mqtt_published": False,
                    "error": "Device not started. Cannot publish to MQTT."
                }

            # Perform upload
            result = self._file_upload_client.upload_file(
                file_path=file_path,
                file_stream=file_stream,
                file_name=file_name
            )

            if not result["success"]:
                result["mqtt_published"] = False
                return result

            # Build MQTT message payload with empty cf object
            mqtt_data = {
                "url": result["url"],
                "cf": {}
            }

            # Determine if this is a gateway device
            is_gateway = False
            if self.has_key(self._data_json, "meta"):
                if self.has_key(self._data_json["meta"], "gtw"):
                    is_gateway = self._data_json["meta"]["gtw"] is not None

            # Build payload based on device type
            if is_gateway:
                # Gateway device - need to include id and tg
                device_id = self._uniqueId
                device_tag = ""

                if self.has_key(self._data_json, "d") and len(self._data_json["d"]) > 0:
                    device_id = self._data_json["d"][0].get("id", self._uniqueId)
                    device_tag = self._data_json["d"][0].get("tg", "")

                mqtt_data["id"] = device_id
                mqtt_data["tg"] = device_tag

            payload = {
                "d": [{
                    "d": mqtt_data
                }]
            }

            # Publish to MQTT
            mqtt_success = self.send_msg_to_broker("FILE", payload)

            result["mqtt_published"] = mqtt_success

            if mqtt_success:
                self.print_debuglog(f"File uploaded and published to MQTT: {result['url']}", 0)
            else:
                self.print_debuglog(f"File uploaded but MQTT publish failed: {result['url']}", 1)

            return result

        except Exception as ex:
            self.print_debuglog(f"UploadImage error: {ex}", 1)
            return {
                "success": False,
                "s3_key": None,
                "bucket": None,
                "url": None,
                "mqtt_published": False,
                "error": str(ex)
            }

    def UploadImageWithClassification(self, file_path=None, file_stream=None, file_name=None, classification=None, custom_attributes=None):
        """
        Upload an image file to S3 and publish classification data to MQTT

        Args:
            file_path: Path to the file (if uploading from file system)
            file_stream: File content as bytes or base64 string (if uploading from memory)
            file_name: Name of file (required if using file_stream)
            classification: Classification result string (can be None)
            custom_attributes: Optional dict of custom attributes to include in MQTT message

        Returns:
            dict: Upload result with keys:
                - success: bool
                - s3_key: S3 object key
                - bucket: Bucket name
                - url: URL path for MQTT message
                - mqtt_published: bool indicating if MQTT message was sent
                - error: Error message (if failed)
        """
        try:
            if self._dispose == True:
                raise(IoTConnectSDKException("00", "you are not able to call this function"))

            if not self._file_upload_client:
                return {
                    "success": False,
                    "s3_key": None,
                    "bucket": None,
                    "url": None,
                    "mqtt_published": False,
                    "error": "File upload client not initialized. Check if fs configuration is available in sync response."
                }

            if self._is_process_started == False:
                return {
                    "success": False,
                    "s3_key": None,
                    "bucket": None,
                    "url": None,
                    "mqtt_published": False,
                    "error": "Device not started. Cannot publish classification data."
                }

            # Upload the file (without sending MQTT)
            upload_result = self._file_upload_client.upload_file(
                file_path=file_path,
                file_stream=file_stream,
                file_name=file_name
            )

            if not upload_result["success"]:
                upload_result["mqtt_published"] = False
                return upload_result

            # Build MQTT message payload with cf object
            cf_data = {}

            # Add classification to cf if provided
            if classification is not None:
                cf_data["classification"] = classification

            # Add custom attributes to cf if provided
            if custom_attributes and isinstance(custom_attributes, dict):
                cf_data.update(custom_attributes)

            mqtt_data = {
                "url": upload_result["url"],
                "cf": cf_data
            }

            # Determine if this is a gateway device
            is_gateway = False
            if self.has_key(self._data_json, "meta"):
                if self.has_key(self._data_json["meta"], "gtw"):
                    is_gateway = self._data_json["meta"]["gtw"] is not None

            # Build payload based on device type
            if is_gateway:
                # Gateway device - need to include id and tg
                # Use the first device or parent device
                device_id = self._uniqueId
                device_tag = ""

                if self.has_key(self._data_json, "d") and len(self._data_json["d"]) > 0:
                    device_id = self._data_json["d"][0].get("id", self._uniqueId)
                    device_tag = self._data_json["d"][0].get("tg", "")

                mqtt_data["id"] = device_id
                mqtt_data["tg"] = device_tag

            payload = {
                "d": [{
                    "d": mqtt_data
                }]
            }

            # Publish to MQTT
            mqtt_success = self.send_msg_to_broker("FILE", payload)

            upload_result["mqtt_published"] = mqtt_success

            if mqtt_success:
                self.print_debuglog(f"File uploaded and classification published: {upload_result['url']}", 0)
            else:
                self.print_debuglog(f"File uploaded but classification publish failed: {upload_result['url']}", 1)

            return upload_result

        except Exception as ex:
            self.print_debuglog(f"UploadImageWithClassification error: {ex}", 1)
            return {
                "success": False,
                "s3_key": None,
                "bucket": None,
                "url": None,
                "mqtt_published": False,
                "error": str(ex)
            }

    def GetCredentials(self):
        """
        Get temporary AWS credentials for file upload using device certificate

        Returns:
            dict: Credentials result with keys:
                - success: bool
                - access_key_id: AWS access key ID
                - secret_access_key: AWS secret access key
                - session_token: AWS session token
                - expiration: Credential expiration time
                - error: Error message (if failed)
        """
        try:
            if self._dispose == True:
                raise(IoTConnectSDKException("00", "you are not able to call this function"))

            if not self._file_upload_client:
                return {
                    "success": False,
                    "access_key_id": None,
                    "secret_access_key": None,
                    "session_token": None,
                    "expiration": None,
                    "error": "File upload client not initialized. Check if fs configuration is available in sync response."
                }

            self.print_debuglog("Getting file upload credentials using device certificate", 0)

            # Get IoT credentials using device certificate
            access_key_id, secret_access_key, session_token = self._file_upload_client._get_iot_credentials()

            if access_key_id and secret_access_key:
                self.print_debuglog("Successfully obtained file upload credentials", 0)
                return {
                    "success": True,
                    "access_key_id": access_key_id,
                    "secret_access_key": secret_access_key,
                    "session_token": session_token,
                    "expiration": "Credentials typically valid for 1 hour",
                    "error": None
                }
            else:
                raise Exception("Failed to obtain credentials from IoT Core")

        except Exception as ex:
            self.print_debuglog(f"GetCredentials error: {ex}", 1)
            return {
                "success": False,
                "access_key_id": None,
                "secret_access_key": None,
                "session_token": None,
                "expiration": None,
                "error": str(ex)
            }

    def Dispose(self):
        try:
            if self._dispose == True:
                self.write_debuglog('[ERR_DC02] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Connection not available",1)
                self.print_debuglog("Connection not available", 1)

                self.write_debuglog('[INFO_DC01] '+'['+ str(self._sId)+'_'+str(self._uniqueId)+"] Device already disconnected: "+self._time,0)
                self.print_debuglog("Device already disconnected ",0)
                return True
            for attr in self.attributes:
                if self.has_key(attr, "evaluation"):
                    attr["evaluation"].destroyed()
                    del attr["evaluation"]
            if self._client and hasattr(self._client, 'Disconnect'):
                self._client.Disconnect()
            self._is_process_started=False
            self._dispose = True
            self._property=None
            self._config = None
            self._cpId = None
            self._uniqueId = None
            self._listner_callback = None
            self._listner_twin_callback = None
            self._listner_direct_callback_list = None
            self._data_json = None
            self._client = None
            self._base_url = ""
            self._thread = None
            self._ruleEval = None
            self._offlineClient = None
            self._lock = None
            self._live_device=[]
            self._debug=False
            return True
        except:
            raise(IoTConnectSDKException("00","Dispose error.."))

    def onOTACommand(self,callback):
        if callback:
            self._listner_ota_callback = callback

    def onModuleCommand(self,callback):
        if callback:
            self._listner_module_callback = callback

    def onDeviceCommand(self,callback):
        if callback:
            self._listner_device_callback = callback

    def onTwinChangeCommand(self,callback):
        if callback:
            self._listner_twin_callback = callback

    def onAttrChangeCommand(self,callback):
        if callback:
            self._listner_attchng_callback = callback

    def onDeviceChangeCommand(self,callback):
        if callback:
            self._listner_devicechng_callback=callback

    def onRuleChangeCommand(self,callback):
        if callback:
            self._listner_rulechng_callback = callback

    def heartbeat_stop(self):
        if self._heartbeat_timer:
            self._heartbeat_timer.cancel()
            self._heartbeat_timer = None

    def onReady(self,callback):
        if callback:
            self._onReady = callback

    def heartbeat_start(self,time):
        if self._heartbeat_timer:
            self._heartbeat_timer.cancel()
        if self._client:
            self._heartbeat_timer=infinite_timer(time,self._client.send_HB)
            self._heartbeat_timer.start()

    def onMessage(self, msg):
        # print("\n====================>>>>>>>>>>>>>>>>>>>>>>>\n")
        # print ("Cloud To Device Message Received::\n",msg)
        # print("\n<<<<<<<<<<<<<<<<<<<<<<<====================\n")
        try:
            if self._dispose == True:
                return
            if msg == None:
                return
            else:
                self._is_process_started = True

                if self.has_key(msg,"data") and msg["data"]:
                    msg=msg["data"]
                if self.has_key(msg,"d") and msg["d"]:
                    msg=msg["d"]
                    self.print_debuglog(msg, 0)
                    if msg['ec'] == 0 and msg["ct"] == 201:
                        if self._getattribute_callback == None:
                            self._data_json["att"] = msg["att"]
                            if self._onReady != None:
                                self._onReady(msg)
                            for attr in self.attributes:
                                attr["evaluation"] = data_evaluation(self.isEdge, attr, self.send_edge_data)
                            self._is_process_started = True
                            self._offlineflag=False
                            self.print_debuglog("Atrributes Get Successfully",0)
                        if self._getattribute_callback:
                            self._getattribute_callback(msg["att"])
                            self._getattribute_callback = None

                    if msg['ec'] == 0 and msg["ct"] == 202:
                        self._data_json["set"] = msg["set"]
                    if msg['ec'] == 0 and msg["ct"] == 203:
                        self._data_json["r"] = msg["r"]
                    if msg['ec'] == 0 and msg["ct"] == 204 != 0:
                        if len(msg['d']) == 0:
                            self._data_json["has"]["d"] = 0
                        self._data_json['d']=[]
                        self._data_json['d'].append({'tg': self._data_json['meta']['gtw']['tg'],'id': self._uniqueId})
                        for i in msg["d"]:
                                self._data_json['d'].append(i)
                        if self._listner_devicechng_callback:
                            self._listner_devicechng_callback(msg)
                    if msg['ec'] == 0 and msg["ct"] == 205:
                        self._data_json["ota"] = msg["ota"]
                    if msg["ct"] == 221:
                        if self._listner_creatchild_callback:
                            if msg["ec"] == 0:
                                self._listner_creatchild_callback({"status":True,"message":self.__child_error_log(msg["ec"])})
                                self._hello_handsake({"mt":204,"sid":self._sId})
                                time.sleep(10)
                            else:
                                self._listner_creatchild_callback({"status":False,"message":self.__child_error_log(msg["ec"])})
                    if msg["ct"] == 222:
                        if self._listner_deletechild_callback:
                            if msg["ec"] == 0:
                                self._listner_deletechild_callback({"status":True,"message":"sucessfuly delete child device"})
                                for i in range(0,len(self._data_json["d"])):
                                    if self._data_json["d"][i] == self.deletechild:
                                        self._data_json["d"].pop(i)
                                        break
                                self._hello_handsake({"mt":204,"sid":self._sId})
                                time.sleep(10)
                            else:
                                self._listner_deletechild_callback({"status":True,"message":"fail to delete child device"})
                        self._listner_deletechild_callback=None
                    return
                else:
                    pass
                if "ct" in msg:
                    if msg["ct"] == CMDTYPE["is_connect"]:
                        msg["uniqueId"] = self._uniqueId
                        if msg["command"] in "False":
                            self._offlineflag = True
                            if self._is_process_started:
                                self.reconnect_device("reconnect")

                        if self._listner_callback:
                            # self._listner_callback(msg["data"])
                            self._listner_callback(msg)
                        self.write_debuglog('[INFO_CM09] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] 0x116 sdk connection status: " + msg["command"],0)
                        self.print_debuglog("0x116 sdk connection status: " + msg["command"], 0)
                        return
                    
                    if msg["ct"] == CMDTYPE["stream_start"]:
                        print("Video_Stream_Task : Starting Streaming")

                        # if self.has_key(self._data_json["p"], "vs"):

                        if (self._kinesis_stream_status == False):
                            print("Video_Stream_Task : Start Kinesis video stream")

                            # Read webrtc flag and carn from the incoming command
                            webrtc_flag = False
                            channel_arn = None
                            try:
                                webrtc_flag = bool(msg.get("webrtc", False))
                                channel_arn = msg.get("carn")
                            except Exception:
                                webrtc_flag = False
                                channel_arn = None

                            stream_id_concat = self._data_json["p"]["id"]

                            if webrtc_flag:
                                # webrtc=true path -> start KVS WebRTC MASTER client using device certificate flow
                                if not channel_arn:
                                    print("Video_Stream_Task : webrtc requested but carn not provided in command")
                                else:
                                    print(f"Video_Stream_Task : Starting KVS WebRTC MASTER on channel {channel_arn}")
                                    # Extract thing name (uid) from the channel ARN
                                    # ARN: ...channel/{channel-name}/{timestamp} -> uid = channel-name
                                    webrtc_uid = channel_arn.split('/')[-2]
                                    # start_kvs_webrtc_from_devicecert will obtain temporary creds using device certs
                                    threading.Thread(
                                        target=start_kvs_webrtc_from_devicecert,
                                        args=(
                                            channel_arn,
                                            webrtc_uid,
                                            self._property["certificate"]["SSLCaPath"],
                                            self._property["certificate"]["SSLCertPath"],
                                            self._property["certificate"]["SSLKeyPath"],
                                            self._aws_credential_endpoint_URL,
                                            self._property.get("CameraOptions", {})
                                        ),
                                        daemon=True
                                    ).start()
                                    self._kinesis_stream_status = True
                                    print("Video_Stream_Task : KVS WebRTC MASTER started")
                            else:
                                # webrtc=false or absent -> start existing GStreamer kvssink pipeline
                                try:
                                    access_key_id, stream_key, sessionToken = get_kinesis_cer(
                                        self._data_json["p"]["id"],
                                        self._property["certificate"]["SSLCaPath"],
                                        self._property["certificate"]["SSLCertPath"],
                                        self._property["certificate"]["SSLKeyPath"],
                                        self._aws_credential_endpoint_URL
                                    )
                                except Exception as ex:
                                    print(f"Video_Stream_Task : Failed to obtain Kinesis credentials: {ex}")
                                    return

                                gst_thread = threading.Thread(target=start_gstreamer, args=(
                                    stream_id_concat,
                                    access_key_id,
                                    stream_key,
                                    sessionToken,
                                    self._property.get("CameraOptions", {})
                                ), daemon=True)
                                gst_thread.start()

                                self._kinesis_stream_status = True
                                print("Video_Stream_Task : Streaming started")

                        else:
                            print("Video_Stream_Task : Streaming already started")
                        

                    if msg["ct"] == CMDTYPE["stream_stop"]:
                        # Uncomment after SYNC api done to check if sync has object of "vs"
                        # if self.has_key(self._data_json["p"], "vs"):
                        if(self._kinesis_stream_status == False):
                            print("Video_Stream_Task : No Streaming found")
                        else:
                            stop_gstreamer()
                            print("Video_Stream_Task : Streaming Stopped")
                            self._kinesis_stream_status = False

            if self._is_process_started == False:
                return
            if "ct" not in msg:
                self.print_debuglog("Command Received : " + json.dumps(msg), 0)
                return
            _tProcess = None
            if msg["ct"] == CMDTYPE["U_ATTRIBUTE"]:
                if self._listner_attchng_callback:
                    self._listner_attchng_callback(msg)
                self.print_debuglog(str(CMDTYPE["U_ATTRIBUTE"])+" U_ATTRIBUTE command received...", 0)
                self.print_debuglog(msg, 0)
                _tProcess = threading.Thread(target = self.reset_process_sync, args = ["ATT"])
            elif msg["ct"] == CMDTYPE["Stop_Hr_beat"]:
                self.print_debuglog(str(CMDTYPE["Stop_Hr_beat"])+" Stop_Hr_beat command received...", 0)
                self.print_debuglog(msg, 0)
                self.heartbeat_stop()
            elif msg["ct"] == CMDTYPE["Start_Hr_beat"]:
                HBtime=msg["f"]
                self.print_debuglog(str(CMDTYPE["Start_Hr_beat"])+" Start_Hr_beat command received...", 0)
                self.print_debuglog(msg, 0)
                self.heartbeat_start(HBtime)
            elif msg["ct"] == CMDTYPE["U_SETTING"]:
                self.print_debuglog(str(CMDTYPE["U_SETTING"])+" U_SETTING command received...", 0)
                self.print_debuglog(msg, 0)
                _tProcess = threading.Thread(target = self.reset_process_sync, args = ["SETTING"])
            elif msg["ct"] == CMDTYPE["U_DEVICE"]:
                self.print_debuglog(str(CMDTYPE["U_DEVICE"])+" U_DEVICE command received...", 0)
                self.print_debuglog(msg, 0)
                _tProcess = threading.Thread(target = self.reset_process_sync, args = ["DEVICE"])
            elif msg["ct"] == CMDTYPE["U_RULE"]:
                if self._listner_rulechng_callback:
                    self._listner_rulechng_callback(msg)
                self.print_debuglog(str(CMDTYPE["U_RULE"])+" U_RULE command received...", 0)
                self.print_debuglog(msg, 0)
                _tProcess = threading.Thread(target = self.reset_process_sync, args = ["RULE"])
            elif msg["ct"] == CMDTYPE["RESETPWD"]:
                self.print_debuglog(str(CMDTYPE["RESETPWD"])+" RESETPWD command received...", 0)
                self.print_debuglog(msg, 0)
                _tProcess = threading.Thread(target = self.reset_process_sync, args = ["protocol"])
            elif msg["ct"] == CMDTYPE["DATA_FRQ"]:
                self.print_debuglog(str(CMDTYPE["DATA_FRQ"])+" DATA_FRQ command received...", 0)
                self.print_debuglog(msg, 0)
                self._data_json['meta']["df"]= msg["df"]
                self._data_frequency = msg["df"]
            elif msg["ct"] == CMDTYPE["UCART"]:
                self.print_debuglog(str(CMDTYPE["UCART"])+" UCART command received...", 0)
                self.print_debuglog(msg, 0)
                pass
            elif msg["ct"] == CMDTYPE["DCOMM"]:
                self.print_debuglog(str(CMDTYPE["DCOMM"])+" DCOMM command received...", 0)
                self.print_debuglog(msg, 0)
                if self._listner_device_callback != None:
                    self._listner_device_callback(msg)
            elif msg["ct"] == CMDTYPE["FIRMWARE"]:
                self.print_debuglog(str(CMDTYPE["FIRMWARE"])+" FIRMWARE command received...", 0)
                self.print_debuglog(msg, 0)
                if self._listner_ota_callback:
                    self._listner_ota_callback(msg)
            elif msg["ct"] == CMDTYPE["MODULE"]:
                self.print_debuglog(str(CMDTYPE["MODULE"])+" MODULE command received...", 0)
                self.print_debuglog(msg, 0)
                if self._listner_module_callback:
                    self._listner_module_callback(msg)
            elif msg["ct"] == CMDTYPE["U_barred"] or msg["ct"] == CMDTYPE["D_Disabled"] or msg["ct"] == CMDTYPE["D_Released"] or msg["ct"] == CMDTYPE["STOP"]:
                if msg["ct"] == CMDTYPE["U_barred"]:
                    self.print_debuglog(str(CMDTYPE["U_barred"])+" U_barred command received...", 0)
                    self.print_debuglog(msg, 0)
                if msg["ct"] == CMDTYPE["D_Disabled"]:
                    self.print_debuglog(str(CMDTYPE["D_Disabled"])+" D_Disabled command received...", 0)
                    self.print_debuglog(msg, 0)
                if msg["ct"] == CMDTYPE["D_Released"]:
                    self.print_debuglog(str(CMDTYPE["D_Released"])+" D_Released command received...", 0)
                    self.print_debuglog(msg, 0)
                if msg["ct"] == CMDTYPE["STOP"]:
                    self.print_debuglog(str(CMDTYPE["STOP"])+" STOP command received...", 0)
                    self.print_debuglog(msg, 0)
                self._is_process_started=False
                if self._offlineClient:
                    self._offlineClient.clear_all_files()
                if self._client and hasattr(self._client, 'Disconnect'):
                    self._client.Disconnect()
            else:
                self.print_debuglog("Message : " + json.dumps(msg), 0)


            if _tProcess != None:
                _tProcess.setName("PSYNC")
                _tProcess.daemon = True
                _tProcess.start()

        except Exception as ex:
            self.print_debuglog("Message process failed..."+ str(ex), 1)

    def onTwinMessage(self, msg,value):
        try:
            if self._dispose == True:
                raise(IoTConnectSDKException("00", "you are not able to call this function"))
            if self._is_process_started == False:
                return
            #if self.has_key("payload", msg) == False and ((msg.payload == None) or (msg.payload == '')):
            #    return
            #msg = msg.payload.decode("utf-8")
            #if msg == None or len(msg) == 0 :
            #    return
            #msg = json.loads(msg)
            if  value:
                temp=msg
                msg={}
                msg["desired"]=temp
                msg["uniqueId"] = self._uniqueId
            else:
                msg["uniqueId"] = self._uniqueId
            if self._listner_twin_callback != None:
                self._listner_twin_callback(msg)
        except Exception as ex:
            # print("Message process failed...",ex)
            self.print_debuglog("Message process failed..." + ex, 1)

    def regiter_directmethod_callback(self,methodname,callback):
        self._listner_direct_callback_list[methodname]=callback

    def onDirectMethodMessage(self,msg,methodname,requestId):
        try:
            if self._listner_direct_callback_list :
                self._listner_direct_callback_list[str(methodname)](msg,methodname,requestId)
        except Exception as ex:
            # print(ex)
            self.print_debuglog("Message process failed..." + ex, 1)

    def init_protocol(self):
        try:
            protocol_cofig = self.protocol
            name = protocol_cofig["n"]
            protocol_cofig["pf"] = self._pf
            auth_type = self._data_json["meta"]['at']
            if auth_type == 2 or auth_type == 3 or auth_type == 7:
                cert = self._config["certificate"]
                
                if util.cert_validate(cert, auth_type) == False:
                    self.write_debuglog('[ERR_IN06] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] sdkOption: Certificate is missing or invalid",1)
                    self.print_debuglog("sdkOption: Certificate is missing or invalid",1)
                    raise(IoTConnectSDKException("05"))
                
                # if len(cert) == 3:
                #     for prop in cert:
                #         if os.path.isfile(cert[prop]) == True:
                #             pass
                #         else:
                #             self.write_debuglog('[ERR_IN06] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] sdkOption: set proper certificate file path and try again",1)
                #             raise(IoTConnectSDKException("05"))
                # else:
                #     self.write_debuglog('[ERR_IN06] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] sdkOption: set proper certificate file path and try again",1)
                #     raise(IoTConnectSDKException("01","Certificate/Key in Sdkoption"))

            if auth_type == 5:
                if ("devicePrimaryKey" in self._property) and self._property["devicePrimaryKey"]:
                    protocol_cofig["pwd"]=self.generate_sas_token(protocol_cofig["h"],self._property["devicePrimaryKey"])
                else:
                    raise(IoTConnectSDKException("01", "devicePrimaryKey"))

            if self._client != None:
                self._client = None

            if name == "mqtt":
                self._client = mqttclient(auth_type, protocol_cofig, self._config, self.onMessage,self.onDirectMethodMessage, self.onTwinMessage, self._debug)
            elif name == "http" or name == "https":
                self._client = httpclient(protocol_cofig, self._config)
            else:
                self._client = None
        except Exception as ex:
            raise(ex)

    def _hello_handsake(self,data):
        if self._client:
            self._client.Send(data,"Di")

    def process_sync(self, option):
        try:
            self._time_s=10
            isReChecking = False
            if option == "all":
                url = self._base_url
                response = self.post_call(url)
                # print (response)
                self.print_debuglog(response, 0)
                if response == None:
                    if self._offlineflag == True:
                        isReChecking=True
                    else:
                        raise(IoTConnectSDKException("01", "Sync response"))
                else:
                    if self.has_key(response, "d"):
                        response = response["d"]
                        self.write_debuglog('[INFO_IN01] '+'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Device information received successfully: "+ self._time ,0)
                        self.print_debuglog("Device information received successfully", 0)
                        self._offlineflag = False
                    else:
                        raise(IoTConnectSDKException("03", response["message"]))
                    if response["ec"] != ErorCode["OK"]:
                        isReChecking = True
                        self._time_s=60
                    if response["ec"] == ErorCode["DEV_NOT_FOUND"] or response["ec"] == ErorCode["CPID_NOT_FOUND"] :
                        self.write_debuglog('[ERR_IN10] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Device Information not found",1)
                        self.print_debuglog("Device Information not found", 0)
            else:
                if option == "ATT":
                    self._hello_handsake({"mt":201})
                elif option == "SETTING":
                    self._hello_handsake({"mt":202})
                elif option == "DEVICE":
                    self._hello_handsake({"mt":204})
                elif option == "RULE":
                    self._hello_handsake({"mt":203})
                else:
                    pass
            if isReChecking:
                # print("\nDisConnected...")
                # print("\nTrying to Connect...")
                self.print_debuglog("DisConnected...", 0)
                self.print_debuglog("Trying to Connect...", 0)
                
                _tProcess = threading.Thread(target = self.reset_process_sync, args = [option])
                time.sleep(self._time_s)
                _tProcess.setName("PSYNC")
                _tProcess.daemon = True
                _tProcess.start()
                return
            else:
                # Pre Process
                self.clear_object(option)
                # --------------------------------
                if option == "all":
                    self._is_process_started = False
                    self._data_json = response
                    self.init_protocol()
                    if self._pf == "aws":
                        data = { "_connectionStatus": "true" }
                        self._client.SendTwinData(data)
                        # print("\nPublish connection status shadow sucessfully...")
                        self.print_debuglog("Publish connection status shadow sucessfully...", 0)

                    if self.has_key(self._data_json,"has") and self._data_json["has"]["d"]:
                        self._hello_handsake({"mt":204})
                        time.sleep(10)                       
                    else:
                        if self._data_json['meta']['gtw'] != None:
                            self._data_json['d']=[{'tg': self._data_json['meta']['gtw']['tg'],'id': self._uniqueId}]
                        else:
                            self._data_json['d']=[{'tg': '','id': self._uniqueId}]

                    if self.has_key(self._data_json,"has") and self._data_json["has"]["attr"]:
                        self._hello_handsake({"mt":201})

                    if self.has_key(self._data_json,"has") and self._data_json["has"]["set"]:
                        self._hello_handsake({"mt":202})

                    if self.has_key(self._data_json,"has") and self._data_json["has"]["r"]:
                        self._hello_handsake({"mt":203})

                    if self.has_key(self._data_json,"has") and self._data_json["has"]["ota"]:
                        self._hello_handsake({"mt":205})
                        
                    if "df" in self._data_json['meta'] and self._data_json['meta']["df"]:
                        self._data_frequency=self._data_json['meta']["df"]

                    # kinesis video stream config in Sync call
                    if self.has_key(self._data_json["p"], "vs"):
                        print("Video_Stream_Task : Streaming Object found")
                        url = self._data_json["p"]["vs"]["url"]
                        self._aws_credential_endpoint_URL = url
                        print(self._aws_credential_endpoint_URL)
                        self._kinesis_stream_as = self._data_json["p"]["vs"]["as"]
                        self._kinesis_stream_carn = self._data_json["p"]["vs"].get("carn", "")
                        print(f"Video_Stream_Task : as={self._kinesis_stream_as}, carn={self._kinesis_stream_carn}")

                        if(self._kinesis_stream_as == True):
                            print(self._uniqueId)
                            print(self._property)

                            if self._kinesis_stream_carn:
                                # carn is non-empty -> auto-start WebRTC signaling channel
                                # Extract thing name (uid) from channel ARN
                                # ARN: ...channel/{channel-name}/{timestamp} -> uid = channel-name
                                vs_webrtc_uid = self._kinesis_stream_carn.split('/')[-2]
                                print("Video_Stream_Task : Auto Streaming ON (WebRTC signaling channel)")
                                threading.Thread(
                                    target=start_kvs_webrtc_from_devicecert,
                                    args=(
                                        self._kinesis_stream_carn,
                                        vs_webrtc_uid,
                                        self._property["certificate"]["SSLCaPath"],
                                        self._property["certificate"]["SSLCertPath"],
                                        self._property["certificate"]["SSLKeyPath"],
                                        self._aws_credential_endpoint_URL,
                                        self._property.get("CameraOptions", {})
                                    ),
                                    daemon=True
                                ).start()
                                self._kinesis_stream_status = True
                                print("Video_Stream_Task : KVS WebRTC MASTER auto-started")
                            else:
                                # carn is empty -> auto-start PutMedia (GStreamer/kvssink)
                                print("Video_Stream_Task : Auto Streaming ON (PutMedia)")
                                access_key_id, stream_key, sessionToken = get_kinesis_cer(self._data_json["p"]["id"], self._property["certificate"]["SSLCaPath"], self._property["certificate"]["SSLCertPath"], self._property["certificate"]["SSLKeyPath"], self._aws_credential_endpoint_URL)
                                print("Video_Stream_Task : Kinesis video stream credentials received")

                                stream_id_concat = self._data_json["p"]["id"]

                                gst_thread = threading.Thread(
                                        target=start_gstreamer,
                                         args=(stream_id_concat,
                                             access_key_id,
                                              stream_key,
                                               sessionToken,
                                               self._property["CameraOptions"]
                                               ))
                                gst_thread.start()
                                self._kinesis_stream_status = True

                        else:
                            print("Video_Stream_Task : Auto Streaming OFF, wait for start command")
                    else:
                        print("Video_Stream_Task : No Streaming Object found")

                # Initialize file upload client if fs config is available
                if self.has_key(self._data_json, "p"):
                    if self.has_key(self._data_json["p"], "fs"):
                        print("File_Upload_Task : File upload configuration found")
                        self._fs_config = self._data_json["p"]["fs"]

                        # Initialize file upload client if certificate-based authentication
                        if self._property.get("certificate"):
                            cert = self._property["certificate"]
                            try:
                                self._file_upload_client = FileUploadClient(
                                    unique_id=self._data_json["p"]["id"],
                                    ca_cert=cert.get("SSLCaPath"),
                                    device_cert=cert.get("SSLCertPath"),
                                    device_key=cert.get("SSLKeyPath"),
                                    fs_config=self._fs_config,
                                    debug=self._debug
                                )
                                print("File_Upload_Task : File upload client initialized successfully")
                            except Exception as fs_ex:
                                print(f"File_Upload_Task : Failed to initialize file upload client: {fs_ex}")
                                self._file_upload_client = None
                        else:
                            print("File_Upload_Task : Certificate-based authentication required for file upload")
                    else:
                        print("File_Upload_Task : No file upload configuration found")

        except Exception as ex:
            raise ex

    def find_df(self,seconds):
        seconds = seconds % (24 * 3600)
        hour = seconds // 3600
        seconds %= 3600
        minutes = seconds // 60
        seconds %= 60
        times= datetime.datetime.strptime("%02d%02d%02d" % (hour, minutes, seconds),'%H%M%S')
        return times

    def SendData(self,jsonArray):
        try:
            if self._dispose == True:
                raise(IoTConnectSDKException("00", "you are not able to call this function"))
            if self._is_process_started == False:
                self.write_debuglog('[ERR_SD04] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Device is barred SendData() method is not permitted",1)
                self.print_debuglog("Device is barred SendData() method is not permitted",1)
                return
            if self.has_key(self._data_json,"att") == False:
                return

            nowtime=datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            time_zero = datetime.datetime.strptime('000000', '%H%M%S')
            edge_flt_flag = False
            if self._dftime != None:
                if int(nowtime) >= self._dftime:
                    nowtime=datetime.datetime.strptime(str(nowtime),"%Y%m%d%H%M%S")
                    self._dftime = int((nowtime - time_zero + self.find_df(self._data_frequency)).strftime("%Y%m%d%H%M%S"))
                    if self.isEdge:
                        edge_flt_flag=True
                else:
                    if not self.isEdge:
                        return
            else:
                nowtime=datetime.datetime.strptime(str(nowtime),"%Y%m%d%H%M%S")
                self._dftime = int((nowtime - time_zero + self.find_df(self._data_frequency)).strftime("%Y%m%d%H%M%S"))
                if self.isEdge:
                    edge_flt_flag=True
            #--------------------------------
            rul_data = []
            rpt_data = self._data_template
            flt_data = self._data_template
            for obj in jsonArray:
                rul_data = []
                uniqueId = obj["uniqueId"]
                time = obj["time"]
                sensorData = obj["data"]

                for attr in self.attributes:
                    if self.has_key(attr, "evaluation"):
                        evaluation = attr["evaluation"]
                        evaluation.reset_get_rule_data()
                for d in self.devices:
                    if d["id"] == uniqueId:
                        if uniqueId not in self._live_device:
                            self._live_device.append(uniqueId)
                        if self._data_json['has']['d']:
                            tg = d["tg"]
                            r_device = {
                                "id": uniqueId,
                                "dt": time,
                                "tg": tg
                            }
                        else:
                            r_device = {
                                "id": uniqueId,
                                "dt": time
                            }
                            if d["tg"] != None:
                                r_device["tg"] = d["tg"]
                        
                        f_device = copy.deepcopy(r_device)
                        r_attr_s = {}
                        f_attr_s = {}
                        real_sensor = []
                        for attr in self.attributes:
                            if attr["p"] == "" and self.has_key(attr, "evaluation"):
                                evaluation = attr["evaluation"]
                                evaluation.reset_get_rule_data()
                                for dObj in attr["d"]:
                                    child=True
                                    if self._data_json['has']['d']:
                                        if tg == dObj["tg"]:
                                            pass
                                        else:
                                            child=False
                                    if child and self.has_key(sensorData, dObj["ln"]):
                                        value = sensorData[dObj["ln"]]
                                        real_sensor.append(dObj["ln"])
                                        if self.isEdge:
                                            if type(value) == str:
                                                try:
                                                    sub_value=float(value)
                                                except:
                                                    real_sensor.remove(dObj["ln"])
                                        if value != None:
                                            row_data = evaluation.process_data(dObj, attr["p"], value,self._validation)
                                            if row_data and self.has_key(row_data,"RPT"):
                                                for key, value in row_data["RPT"].items():
                                                    r_attr_s[key] = value
                                            if row_data and self.has_key(row_data, "FLT"):
                                                for key, value in row_data["FLT"].items():
                                                    f_attr_s[key] = value
                                        else:
                                            pass
                                            #f_attr_s[sensorData[dObj]]
                                data = evaluation.get_rule_data()
                                if data != None:
                                    rul_data.append(data)

                            elif attr["p"] != "" and self.has_key(attr, "evaluation") and self.has_key(sensorData, attr["p"]) == True:
                                child = True
                                if self._data_json['has']['d']:
                                    if tg == attr["tg"]:
                                        pass
                                    else:
                                        child = False
                                if child:
                                    evaluation = attr["evaluation"]
                                    evaluation.reset_get_rule_data()
                                    real_sensor.append(attr["p"])
                                    sub_sensors=[]
                                    for dObj in attr["d"]:
                                        if self.has_key(sensorData[attr["p"]], dObj["ln"]):
                                            sub_sensors.append(dObj["ln"])
                                            value = sensorData[attr["p"]][dObj["ln"]]
                                            if self.isEdge:
                                                if type(value) == str:
                                                    try:
                                                        sub_value=float(value)
                                                    except:
                                                        sub_sensors.remove(dObj["ln"])
                                            if value != None:
                                                row_data = evaluation.process_data(dObj, attr["p"], value,self._validation)

                                                if row_data and self.has_key(row_data, "RPT"):
                                                    if self.has_key(r_attr_s, attr["p"]) == False:
                                                        r_attr_s[attr["p"]] = {}
                                                    for key, value in row_data["RPT"].items():
                                                        r_attr_s[attr["p"]][key] = value

                                                if row_data and self.has_key(row_data, "FLT"):
                                                    if self.has_key(f_attr_s, attr["p"]) == False:
                                                        f_attr_s[attr["p"]] = {}
                                                    for key, value in row_data["FLT"].items():
                                                        f_attr_s[attr["p"]][key] = value
                                    unsensor = sensorData[attr["p"]].keys()
                                    unmatch_sensor= list((set(unsensor)- set(sub_sensors)))
                                    for unmatch in unmatch_sensor:
                                        if self.has_key(f_attr_s, attr["p"]) == False:
                                            f_attr_s[attr["p"]] = {}
                                        f_attr_s[attr["p"]][unmatch]=sensorData[attr["p"]][unmatch]
                                    data = evaluation.get_rule_data()
                                    if data != None:
                                        rul_data.append(data)
                        unsensor=sensorData.keys()
                        unmatch_sensor= list((set(unsensor)- set(real_sensor)))
                        for unmatch in unmatch_sensor:
                            f_attr_s[unmatch]=sensorData[unmatch]
                            #--------------------------------
                        #--------------------------------
                        if self.isEdge and self.hasRules and len(rul_data) > 0:
                            for rule in self.rules:
                                rule["id"]=uniqueId
                                self._ruleEval.evalRules(rule, rul_data)
                        if len(r_attr_s.items()) > 0:
                            r_device["d"]=r_attr_s
                            rpt_data["d"].append(r_device)

                        if len(f_attr_s.items()) > 0:
                            f_device["d"]=f_attr_s
                            flt_data["d"].append(f_device)

            #--------------------------------
            print("rtp: ",rpt_data)
            print("flt: ",flt_data)

            msg_status = False

            if len(rpt_data["d"]) > 0:
                msg_status = self.send_msg_to_broker("RPT", rpt_data)

            if len(flt_data["d"]) > 0:
                if self.isEdge:
                    if edge_flt_flag:
                        msg_status = self.send_msg_to_broker("FLT", flt_data)
                else:
                    msg_status = self.send_msg_to_broker("FLT", flt_data)
            #--------------------------------

            return msg_status

        except Exception as ex:
            if self._dispose == False:
                # print(ex)
                self.print_debuglog(ex, 1)
            else:
                # print(ex.message)
                self.print_debuglog(ex.message, 1)

    def sendAckModule(self,ackGuid, status, msg):
        if self._dispose == True:
            raise(IoTConnectSDKException("00", "you are not able to call this function"))
        if self._is_process_started == False:
            return
        if not msg:
            # print("sendAckModule: msg is empty.")
            self.print_debuglog("sendAckModule: msg is empty.", 1)
        if ackGuid != None :
            pass
        else:
            raise(IoTConnectSDKException("00", "sendAckModule: ackGuid not valid."))
        try:
            template = self._Ack_data_template
            template["type"] = 2
            template["st"] = status
            template["msg"] = msg
            template["ack"] = ackGuid
            if ackGuid != None:
                self.send_msg_to_broker("CMD_ACK", template)
        except Exception as ex:
            raise(ex)

    def sendOTAAckCmd(self,ackGuid, status, msg,childId=None):
        if self._dispose == True:
            raise(IoTConnectSDKException("00", "you are not able to call this function"))
        if self._is_process_started == False:
            return
        ischild = False
        if childId != None and type(childId) == str:
            for d in self.devices:
                if d["id"] == childId:
                    ischild=True
        if not msg:
            # print("sendAckModule: msg is empty.")
            self.print_debuglog("sendOTAAckCmd: msg is empty.", 1)
            
        if ackGuid != None :
            pass
        else:
            raise(IoTConnectSDKException("00", "sendAckModule: ackGuid not valid."))
        try:
            template = self._Ack_data_template
            template["d"]["type"] = 1
            template["d"]["st"] = status
            template["d"]["msg"] = msg
            template["d"]["ack"] = ackGuid
            if ischild:
                template["d"]["cid"] = childId
                if ackGuid != None:
                    # print(template)
                    self.send_msg_to_broker("FW", template)
            elif childId:
                pass
            else:
                self.send_msg_to_broker("FW", template)
        except Exception as ex:
            raise(ex)
        

    def sendAckStreamCmd(self,ackGuid, type, status, msg):
        if self._dispose == True:
            raise(IoTConnectSDKException("00", "you are not able to call this function"))
        if self._is_process_started == False:
            return
        if not msg:
            self.print_debuglog("sendAckStreamCmd: msg is empty.", 1)
        if ackGuid != None :
            pass
        else:
            raise(IoTConnectSDKException("00", "sendAckStreamCmd: ackGuid not valid."))
        try:
            template = self._Ack_data_template
            template["d"]["type"] = type
            template["d"]["st"] = status
            template["d"]["msg"] = msg
            template["d"]["ack"] = ackGuid
            self.print_debuglog(template, 0)
            self.send_msg_to_broker("CMD_ACK", template)
        except Exception as ex:
            raise(ex)

    def sendAckCmd(self,ackGuid, status, msg,childId=None):
        if self._dispose == True:
            raise(IoTConnectSDKException("00", "you are not able to call this function"))
        if self._is_process_started == False:
            return
        ischild = False
        if childId != None and type(childId) == str:
            for d in self.devices:
                if d["id"] == childId:
                    ischild=True
        if not msg:
            # print("sendAckModule: msg is empty.")
            self.print_debuglog("sendAckModule: msg is empty.", 1)
        if ackGuid != None :
            pass
        else:
            raise(IoTConnectSDKException("00", "sendAckModule: ackGuid not valid."))
        try:
            template = self._Ack_data_template
            template["d"]["type"] = 0
            template["d"]["st"] = status
            template["d"]["msg"] = msg
            template["d"]["ack"] = ackGuid
            # print(template)
            self.print_debuglog(template, 0)
            if ischild:
                template["d"]["cid"] = childId
                if ackGuid != None:
                    self.send_msg_to_broker("CMD_ACK", template)
            elif childId:
                pass
            else:
                self.send_msg_to_broker("CMD_ACK", template)
        except Exception as ex:
            raise(ex)
        
    def DirectMethodACK(self,msg,status,requestId):
        if self._dispose == True:
            self.write_debuglog('[ERR_TP02] '+ self._time +'['+ str(self._cpId)+'_'+ str(self._uniqueId) + "] Device is barred Updatetwin() method is not permitted",1)
            raise(IoTConnectSDKException("00", "you are not able to call this function"))
        if self._is_process_started == False:
            return
        if self._client:
            try:
                if type(status) == str or type(status) == int:
                    if type(status) == int:
                        status = str(status)
                if type(requestId) == str or type(requestId) == int:
                    if type(requestId) == int:
                        requestId = str(requestId)
                if type(requestId) == str and type(status) == str:
                    online = self._client.SendDirectData(msg,status,requestId)
            except Exception as ex:
                raise(ex)

    def UpdateTwin(self, key, value):
        try:
            isvalid = True
            if self._dispose == True:
                raise(IoTConnectSDKException("00", "you are not able to call this function"))
            if self._is_process_started == False:
                self.write_debuglog('[ERR_TP02] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Device is barred Updatetwin() method is not permitted",1)
                self.print_debuglog("Device is barred Updatetwin() method is not permitted", 1)
                return
            for i in self.setting:
                if i["ln"] == key:
                    if len(i["dv"]):
                        isvalid = util.twin_validate(i["dt"], i["dv"], value)
                    if isvalid:
                        _Online = False
                        _data = {}
                        _data[key] = value
                        if self._client:
                            _Online = self._client.SendTwinData(_data)
                        if _Online:
                            # print("\nupdate twin data sucessfully...")
                            self.print_debuglog("update twin data sucessfully...", 0)
        except Exception as ex:
            # print(ex)
            self.print_debuglog(ex, 1)

    def send_edge_data(self, data):
        try:
            if self._dispose == True:
                return
            if self._is_process_started == False:
                return
            template = self._data_template
            for d in self.devices:
                if (d["tg"] == data["tg"]) and (d["id"] in self._live_device):
                    if d["tg"] == "" and (not self._data_json['has']['d']):
                        device = {
                            "dt": self._timestamp,
                            "d": [],
                        }
                    else:
                        device = {
                            "id": d["id"],
                            "dt": self._timestamp,
                            "d": [],
                            "tg": d["tg"]
                        }
                    device["d"]=data["d"]
                    template["d"].append(device)
            self.send_msg_to_broker("RPTEDGE", template)
        except Exception as ex:
            # print(ex)
            self.print_debuglog(ex, 1)

    #need to change in 2.1 format
    def send_rule_data(self, data):
        try:
            id = data["id"]
            if self._data_json['has']['d']:
                for d in self.devices:
                    if id == d["id"]:
                        data["tg"] = d["tg"]
            tdata = {
                "dt": "",
                "d": [data],
            }
            tdata["dt"]=self._timestamp
            # print(tdata)
            self.print_debuglog(tdata, 0)
            self.send_msg_to_broker("RMEdge", tdata)
        except Exception as ex:
            # print(ex)
            self.print_debuglog(ex, 1)

    def send_msg_to_broker(self, msgType, data):
        try:
            self._lock.acquire()
            #return

            _Online = False
            if self._client:
                _Online = self._client.Send(data,msgType)

            if _Online:
                if msgType == "RPTEDGE":
                    self.print_debuglog("Publish edge data sucessfully...", 0)
                elif msgType == "RMEdge":
                    self.print_debuglog("Publish rule matched data sucessfully...", 0)
                elif msgType == "CMD":
                    self.print_debuglog("Publish Command data sucessfully...", 0)
                elif msgType == "FW":
                    self.print_debuglog("Publish Firmware data sucessfully...", 0)
                elif msgType == "CMD_ACK":
                    #print (">>command acknowledge ack", data["d"]["ack"])
                    # print("\nPublish command acknowledge data sucessfully... %s" % self._time)
                    # print("\r\nfunction: {}, Line : {}\r\n" .format(inspect.currentframe().f_code.co_name,inspect.currentframe().f_lineno))
                    self.print_debuglog("Publish command acknowledge data sucessfully...", 0)
                    self.write_debuglog('[INFO_CM10] '+'['+ str(self._sId)+'_'+str(self._uniqueId)+"] Command Acknowledgement sucessfull: "+self._time ,0)
                else:
                    # print("\nPublish data sucessfully... %s" % self._time,data,msgType)
                    self.print_debuglog(msgType, 0)
                    self.print_debuglog(data, 0)
                    self.print_debuglog("Publish data sucessfully...", 0)

            if _Online == False:
                if self._offlineClient:
                    if self._offlineClient.Send(data):
                        self.write_debuglog('[INFO_OS02] '+'['+ str(self._sId)+'_'+str(self._uniqueId)+"] Offline data saved: "+self._time,0)
                        # print("\nStoring offline sucessfully... %s" % self._time)
                        self.print_debuglog("Storing offline sucessfully... %s", 0)
                    else:
                        self.write_debuglog('[ERR_OS03] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Unable to read or write file",1)
                        # print("\nYou Unable to store offline data.")
                        self.print_debuglog("You Unable to store offline data.", 1)

            else:
                if self._offlineClient:
                    self._offlineClient.PublishData()

            self._lock.release()
            return _Online
        except Exception as ex:
            # print("send_msg_to_broker : ", ex)
            self.print_debuglog("send_msg_to_broker : FAIL", 1)
            self.print_debuglog(ex, 1)
            self._lock.release()

    def send_offline_msg_to_broker(self, data):
        _Online = False
        if self._client:
            data.update({"od":1})
            _Online = self._client.Send(data,"OD")
            if _Online:
                self.write_debuglog('[INFO_OS01] '+'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Publish offline data: "+ self._time ,0)
                self.print_debuglog("Publish offline data" ,0)
        return _Online

    def command_sender(self, command_text,rule):
        try:
            if self._is_process_started == False:
                return
            template = self._command_template
            if self._data_json != None:
                for d in self.devices:
                    if (rule['con'].find(str(d["tg"])) > -1) and (d["id"] in self._live_device):
                        template["id"] = d["id"]
                        template["command"] = command_text
                        if self._listner_device_callback != None:
                            self._listner_device_callback(template)
        except Exception as ex:
            # print(ex)
            self.print_debuglog(ex, 1)

    def clear_object(self, option):
        try:
            if option == "all" or option == "attribute":
                for attr in self.attributes:
                    if self.has_key(attr, "evaluation"):
                        attr["evaluation"].destroyed()
                        del attr["evaluation"]
        except Exception as ex:
            raise(ex)

    def reset_process_sync(self, option):
        try:
            time.sleep(1)
            self.process_sync(option)
        except Exception as ex:
            # print(ex)
            self.print_debuglog(ex, 1)

    def event_call(self, name, taget, arg):
        _thread = threading.Thread(target=getattr(self, taget), args=arg)
        #_thread.daemon = True
        _thread.setName(name)
        _thread.start()

    def delete_child(self,child_id,callback):
        try:
            if self._dispose == True:
                self.write_debuglog('[ERR_GD03] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Request failed to delete the child device",1)
                self.print_debuglog("Request failed to delete the child device",1)
                raise(IoTConnectSDKException("00", "you are not able to call this function"))
            if self._is_process_started == False:
                return None
            if self._data_json["has"]["d"] != 1:
                raise(IoTConnectSDKException("00", "delete child Device not posibale. it is not gatway device. "))
            for device in self._data_json['d']:
                if child_id == device["id"]:
                    self._listner_deletechild_callback=callback
                    self.deletechild=child_id
                    template={
                        "mt": 222,
                        "d": {
                        "id": child_id
                        }}
                    if self._client:
                        self._client.Send(template,"Di")

        except:
            return None

    def Getdevice(self):
        try:
            if self._dispose == True:
                raise(IoTConnectSDKException("00", "you are not able to call this function"))
            if self._is_process_started == False:
                return None
            return self.devices
        except:
            return None

    def GetAttributes(self,callback):
        try:
            if callback:
                self._getattribute_callback = callback
            # self._hello_handsake({"mt":201,"sid":self._sId})
            self._hello_handsake({"mt":201})
        except Exception as ex:
            self.write_debuglog('[ERR_GA01] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Get Attributes Error",1)
            self.print_debuglog("Get Attributes Error",1)
            return None

    def createChildDevice(self, deviceId, deviceTag, displayName, callback=None):
        try:
            if type(deviceId) != str and type(deviceTag) != str and type(displayName) != str:
                raise(IoTConnectSDKException("00", "Child Device deviceId|deviceTag|displayName all should be string"))

            if self._data_json['meta']['gtw'] == None:
                self.write_debuglog('[ERR_GD04] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Child device create : It is not a Gateway device",1)
                self.print_debuglog("Child device create : It is not a Gateway device",1)
                raise(IoTConnectSDKException("00", "create child Device not posibale it is not gatway device. "))
            if (type(deviceId)) != str and (" " in deviceId):
                raise(IoTConnectSDKException("00", "create child Device in deviceId space is not valid. "))
            template=self._child_template
            template["d"]["dn"]=displayName
            template["d"]["id"]=deviceId
            template["d"]["tg"]=deviceTag
            if callback:
                self._listner_creatchild_callback=callback
            if self._client:
                    self._client.Send(template,"Di")
        except:
            self.write_debuglog('[ERR_GD01] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] Create child Device Error",1)
            self.print_debuglog("Create child Device Error", 1)
            raise(IoTConnectSDKException("04", "createChildDevice"))

    def __child_error_log(self,errorcode):
        error={
            "0": "OK - No Error. Child Device created successfully",
            "1": "Message missing child tag",
            "2": "Message missing child device uniqueid",
            "3": "Message missing child device display name",
            "4": "Gateway device not found",
            "5": "Could not create device, something went wrong",
            "6": "Child device tag is not valid",
            "7": "Child device tag name cannot be same as Gateway device",
            "8": "Child uniqueid is already exists.",
            "9": "Child uniqueid should not exceed 128 characters"
        }
        return error[str(errorcode)]

    def has_key(self, data, key):
        try:
            return key in data
        except:
            return False

    def is_not_blank(self, s):
        return bool(s and s.strip())

    @property
    def isEdge(self):
        try:
            if self._data_json != None and self.has_key(self._data_json["meta"], "edge") and self._data_json["meta"]["edge"] != None:
                return (self._data_json["meta"]["edge"] == 1)
            else:
                return False
        except:
            return False

    @property
    def _child_template(self):
        guid=""
        if self.has_key(self._data_json["meta"],"gtw") and self.has_key(self._data_json["meta"]["gtw"],'g'):
            guid=self._data_json["meta"]["gtw"]['g']
        data={
            "mt": 221,
            "d": {
                    "g": guid,
                    "dn": "",
                    "id": "",
                    "tg": ""
                }
        }
        return data
    @property
    def hasRules(self):
        try:
            key = OPTION["rule"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return len(self._data_json[key]) > 0
            else:
                return False
        except:
            return False

    @property
    def _timestamp(self):
        return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")

    @property
    def _time(self):
        return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.000")

    @property
    def _data_template(self):
        try:
            data = {
                "d": [],
                "dt": ""
            }
            data["dt"] = self._timestamp
            return data
        except:
            raise(IoTConnectSDKException("07", "telementry"))

    @property
    def _Ack_data_template(self):
        try:
            data = {
                "dt": "",
                "d": {
                    "ack": "",
                    "type": 0,
                    "st": 0,
                    "msg": "",
                }
            }
            data["dt"] = self._timestamp
            return data
        except:
            raise(IoTConnectSDKException("07", "telementry"))
    # @property
    def get_file(self):
        debug_path = os.path.join(sys.path[0], "logs")
        path_staus=os.path.exists(debug_path)
        if path_staus:
            for sub_folder in ["debug"]:
                debug_path = os.path.join(debug_path,sub_folder)
                path_staus=os.path.exists(debug_path)
                if path_staus:
                    pass
                else:
                    os.mkdir(debug_path)
        else:
            os.mkdir(debug_path)
            for sub_folder in ["debug"]:
                debug_path = os.path.join(debug_path,sub_folder)
                os.mkdir(debug_path)
        self._debug_output_path = os.path.join(debug_path,"info.txt")
        self._debug_error_path = os.path.join(debug_path,"error.txt")

    @property
    def _command_template(self):
        try:
            data = {
                "guid": "",
                "command": "",
                "ack": None,
                "ct": CMDTYPE["DCOMM"]
            }
            return data
        except:
            raise(IoTConnectSDKException("07", "command"))

    @property
    def attributes(self):
        try:
            key = OPTION["attribute"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return self._data_json[key]
            else:
                return []
        except:
            raise(IoTConnectSDKException("04", "attributes"))

    @property
    def devices(self):
        try:
            key = OPTION["device"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return self._data_json[key]
            else:
                return []
        except:
            raise(IoTConnectSDKException("04", "devices"))

    @property
    def rules(self):
        try:
            key = OPTION["rule"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return self._data_json[key]
            else:
                return []
        except:
            raise(IoTConnectSDKException("04", "rules"))

    @property
    def protocol(self):
        try:
            key = OPTION["protocol"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return self._data_json[key]
            else:
                return None
        except:
            raise(IoTConnectSDKException("04", "protocol"))

    @property
    def setting(self):
        try:
            key = OPTION["setting"]
            if self._data_json != None and self.has_key(self._data_json, key) and self._data_json[key] != None:
                return self._data_json[key]
            else:
                return None
        except:
            raise(IoTConnectSDKException("04", "protocol"))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, exc_tb):
        try:
            self._is_process_started = False
            for attr in self.attributes:
                if self.has_key(attr, "evaluation"):
                    attr["evaluation"].destroyed()
                    del attr["evaluation"]
            if self._client and hasattr(self._client, 'Disconnect'):
                self._is_process_started = False
                self._client.Disconnect()
        except:
            raise(IoTConnectSDKException("00", "Exit"))

    def write_debuglog(self,msg,is_error):
        if self._debug:
            if is_error:
                if self._debug_error_path:
                    with open(self._debug_error_path, "a") as dfile:
                        dfile.write(msg+'\n')
            else:
                if self._debug_output_path:
                    with open(self._debug_output_path,"a") as dfile:
                        dfile.write(msg+'\n')
    
    def print_debuglog(self,msg,is_error):
        if self._debug:
            if is_error:
                print("ERROR : {}".format(msg))
            else:
                print("SDK_INFO : {}".format(msg))

    def win_user(self):
        import win32api
        import ntplib
        ntp_obj = ntplib.NTPClient()
        time_a=datetime.utcfromtimestamp(ntp_obj.request('europe.pool.ntp.org').tx_time)
        win32api.SetSystemTime(time_a.year, time_a.month, time_a.weekday(), time_a.day, time_a.hour , time_a.minute, time_a.second, 0)

    def linux_user(self):
        import ctypes
        import ctypes.util
        import time
        import ntplib

        CLOCK_REALTIME = 0
        class timespc(ctypes.Structure):
            _fields_ = [("tv_sec", ctypes.c_long),("tv_nsec", ctypes.c_long)]

        librt = ctypes.CDLL(ctypes.util.find_library("rt"))
        ts = timespc()
        ntp_obj = ntplib.NTPClient()
        time_a=datetime.fromtimestamp(ntp_obj.request('pool.ntp.org').tx_time)
        time_form=[time_a.year,time_a.month,time_a.day,time_a.hour,time_a.minute,time_a.second]
        ts.tv_sec = int(time.mktime(datetime(*time_form[:6]).timetuple()))
        ts.tv_nsec=0 * 1000000
        librt.clock_settime(CLOCK_REALTIME,ctypes.byref(ts))

    def __init__(self, uniqueId,sdkOptions=None,initCallback=None):
        self._lock = threading.Lock()

#        if sys.platform == 'win32':
#            self.win_user()
#        elif sys.platform == 'linux2':
#            self.linux_user()

        #ByPass SSL Verification
        if (not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None)):
            ssl._create_default_https_context = ssl._create_unverified_context

        if sdkOptions == None:
            self._property = {
            	"certificate" : None,
                "offlineStorage":
                    {
                    "disabled":False,
	                "availSpaceInMb": None,
	                "fileCount": 1
                    },
                "IsDebug":False,
                "keepalive":60
                }
        else:
            self._property = sdkOptions

        if initCallback:
            self._listner_callback=initCallback

        self.get_config()
        if self._debug:
            self.get_file()
       
        if self._config == None:
            raise(IoTConnectSDKException("01", "Config settings"))

        
        self._uniqueId = uniqueId
        if "sId" in self._property:
            self._sId = self._property["sId"]
        if "cpid" in self._property:
            self._cpId = self._property["cpid"]
        if "env" in self._property:
            self._env = self._property["env"]
        if "pf" in self._property:
            self.pf = self._property["pf"]
        
        if not self.is_not_blank(self._uniqueId):
            self.write_debuglog('[ERR_IN05] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId)+']:'+'uniqueId can not be blank',1)
            self.print_debuglog("uniqueId can not be blank", 1)
            raise(IoTConnectSDKException("01", "Unique Id can not be blank"))
        
        if not self.is_not_blank(self._sId) and not self.is_not_blank(self._cpId):
            self.write_debuglog('[ERR_IN04] '+ self._time +'['+ str(self._cpId)+'_'+ str(self._uniqueId)+']:'+'SID / CPID can not be blank',1)
            self.print_debuglog("SID / CPID can not be blank", 1)
            raise(IoTConnectSDKException("01", "SID / CPID can not be blank"))
        
        if "discoveryUrl" in self._property:
            if "http" not in self._property["discoveryUrl"] :
                self.write_debuglog('[ERR_IN02] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId)+ "] Discovery URL can not be blank",1)
                self.print_debuglog("Discovery URL can not be blank", 1)
                raise(IoTConnectSDKException("01", "discoveryUrl"))
            else:
                pass
        else:
            self._property["discoveryUrl"]="https://discovery.iotconnect.io"

        if ("offlineStorage" in self._property) and ("disabled" in self._property["offlineStorage"]) and ("availSpaceInMb" in self._property["offlineStorage"]) and ("fileCount" in self._property["offlineStorage"]) :
            if  self._property["offlineStorage"]["disabled"] == False:
                self._offlineClient = offlineclient(self._uniqueId,self._config, self.send_offline_msg_to_broker)
                self.write_debuglog('[INFO_OS03] '+'['+str(self._uniqueId)+"] File has been created to store offline data: "+self._time,0)
                self.print_debuglog("File has been created to store offline data", 0)
        else:
            # print("offline storage is disabled...")
            self.print_debuglog("offline storage is disabled...", 1)

        if ("skipValidation" in self._property):
            if self._property["skipValidation"]:
                self._validation=False

        self._ruleEval = rule_evaluation(self.send_rule_data, self.command_sender)

        self._base_url, self._pf = self.get_base_url()
        if self._base_url != None:
            self.write_debuglog('[INFO_IN07] '+'['+ str(self._sId)+'_'+ str(self._uniqueId) + "] BaseUrl received to sync the device information: "+ self._time ,0)
            self.print_debuglog("BaseUrl received to sync the device information",0)
            self.process_sync("all")
            try:
                while self._is_process_started == False:
                    time.sleep(0.5)
            except KeyboardInterrupt:
                sys.exit(0)
        else:
            self.write_debuglog('[ERR_IN08] '+ self._time +'['+ str(self._sId)+'_'+ str(self._uniqueId)+ "] Network connection error or invalid url",1)
            self.print_debuglog("Network connection error or invalid url",1)
            raise(IoTConnectSDKException("02"))
