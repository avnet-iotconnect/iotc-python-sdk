Softweb Solutions Inc
IOT Connect SDK : Software Development Kit 1.0.0

Prerequisite tools:

1. Python : Python version 2.7, 3.6 and 3.7
2. pip : pip is compatible to the python version
3. setuptools : Required to install IOTConnect SDK

Installation for python vesion 2.7:

    1. Extract the "iotconnect-sdk-python-v1.0.0.zip"

    2. To install the required libraries use the below command:
	    - Goto SDK directory path using terminal/Command prompt
	    - cd iotconnect-sdk/
        - Extract the iotconnect-sdk-2.0.tar.gz
        - python setup.py install

Installation for python vesion 3.6 and 3.7:

    1. Extract the "iotconnect-sdk-python-v2.0.zip"

    2. To install the required libraries use the below command:
	    - Goto SDK directory path using terminal/Command prompt
	    - cd iotconnect-sdk/
        - pip3 install iotconnect-sdk-2.0.tar.gz

How to run sample:

    1. Using terminal/command prompt goto sample folder
	    - cd iotconnect-sdk/sample 

    For python 2.7 :
    2. please insert you env in example_py2.py
        - python TPM.py 

    For python 3.6 and 3.7 :
    2. please insert you env in example_py2.py
        - python3 TPM.py 

    
Usage :

Import library
python
from iotconnect import IoTConnectSDK


Prerequisite input data *
python
uniqueId = <<uniqueId>>
cpid = <<CPID>> 
env = <<env>> // DEV, QA, POC, AVNETPOC, PROD(Default)
scopeId = <<scopeId>> // you will get it from provider.

- SdkOptions is for the SDK configuration and need to parse in SDK object initialize call. You need to manage the below onfiguration as per your device authentications.
sdkOptions = {
    "certificate" : { //For SSL CA signed and SelfSigned authorized device only
        "SSLKeyPath"	: "<< SystemPath >>/device.key",
		"SSLCertPath"   : "<< SystemPath >>/device.pem",
		"SSLCaPath"     : "<< SystemPath >>/rootCA.pem"
	},
    "offlineStorage": { 
		"disabled": false, //default value = false, false = store data, true = not store data 
		"availSpaceInMb": 1, //size in MB, Default value = unlimted
		"fileCount": 5 // Default value = 1
	},
    "IsDebug":False,
    "discoveryUrl" : "https://discovery.iotconnect.io" // Mandatory parameter to get device details
}
Note: sdkOptions is a mandatory parameter for sdk object initialize call. 
	"certificate" : It indicated to define the path of the certificate file. Mandatory for X.509 device CA signed and self-signed authentication type only.
		- SSLKeyPath: your device key
        - SSLCertPath: your device certificate
        - SSLCaPath : Root CA certificate
	"offlineStorage" : Define the configuration related to the offline data storage 
		- disabled : False = offline data storing, true = not storing offline data 
		- availSpaceInMb : Define the file size of offline data which should be in (MB)
		- fileCount : Number of files need to create for offline data
    "discoveryUrl" : (*) Discovery URL is mandatory parameter to get device details
    "IsDebug":  False\True (True you will get the Debuging log in logs/debug" folder)
To get the device information and connect to the device
python
with IoTConnectSDK(cpId, uniqueId,scopeId, DeviceCallback, TwinUpdateCallback,sdkOptions,env) as sdk:


To receive the command from Cloud to Device(C2D) 
python
def callbackMessage(msg):
    print(msg)


To receive the twin from Cloud to Device(C2D) 
python
def callbackTwinMessage(msg):
    print(msg)


To get the list of attributes
python
sdk.GetAttributes()


Data input format
python
sendTeledata = [{
    "uniqueId": "123456",
    "time" : '2018-05-24T10:06:17.857Z', //Date format should be as defined
    "data": {
        "temperature": 15.55,
        "humidity" : 27.97,
        "weight" : 36,
        "gyroscope" : {
            'x' : -1.2,
            'y' : 0.25,
            'z' : 1.1,
        }
    }
}]


To send the data from Device To Cloud(D2C)
python
sdk.SendData(sendTeledata)


To update the Twin Property

python
var key = "firmware_version";
var value = "4.0";
sdk.UpdateTwin(key, value)


- To configure the secure SSL/x509 connection follow below step for CA or CA Selfsiged certificate
	- Open file : sample/properties.json
    - Set SSL/x509 certificate path for CA sign and Selfsign certificate like as below
    - Set max size of offline storage and no of file generate during store data like as below

json
{
	"certificate" : { 
		"SSLKeyPath"	: "<< file path >>/key.pem",
		"SSLCertPath"   : "<< file path >>/cert.pem",
		"SSLCaPath"     : "<< file path >>/ca.cert.pem"
	},
    	"maxSize": 5,
	"fileCount": 5
}


