"""
  ******************************************************************************
  * @file   : iotconnect-sdk-1.0-firmware-python_msg-2_1.py
  * @author : Softweb Solutions An Avnet Company
  * @modify : 07-03-2025
  * @brief  : Firmware part for Python SDK 2.1
  ******************************************************************************
"""

"""
 * Hope you have installed the Python SDK v2.1 as guided in README.md file or from documentation portal. 
 * Import the IoTConnect SDK package and other required packages
"""

import sys
import json
import time
import threading
import random
from iotconnect import IoTConnectSDK
from datetime import datetime, timezone
import os


"""
* ## Prerequisite parameter to run this sampel code
* cpId         :: It need to get from the IoTConnect platform "Settings->Key Vault". 
* uniqueId     :: Its device ID which register on IotConnect platform and also its status has Active and Acquired
* env          :: It need to get from the IoTConnect platform "Settings->Key Vault". 
* interval     :: send data frequency in seconds
* sdkOptions   :: It helps to define the path of self signed and CA signed certificate as well as define the offlinne storage configuration.
"""

UniqueId = "reInvent"

Sdk=None
interval = 10
# add Direct Method
directmethodlist={}
ACKdirect=[]
device_list=[]
readyStatus = False

"""
* sdkOptions is optional. Mandatory for "certificate" X.509 device authentication type
* "certificate" : It indicated to define the path of the certificate file. Mandatory for X.509/SSL device CA signed or self-signed authentication type only.
* 	- SSLKeyPath: your device key
* 	- SSLCertPath: your device certificate
* 	- SSLCaPath : Root CA certificate
* 	- Windows + Linux OS: Use "/" forward slash (Example: Windows: "E:/folder1/folder2/certificate", Linux: "/home/folder1/folder2/certificate")
* "offlineStorage" : Define the configuration related to the offline data storage 
* 	- disabled : false = offline data storing, true = not storing offline data 
* 	- availSpaceInMb : Define the file size of offline data which should be in (MB)
* 	- fileCount : Number of files need to create for offline data
* "devicePrimaryKey" : It is optional parameter. Mandatory for the Symmetric Key Authentication support only. It gets from the IoTConnect UI portal "Device -> Select device -> info(Tab) -> Connection Info -> Device Connection".
    - - "devicePrimaryKey": "<<your Key>>"
* Note: sdkOptions is optional but mandatory for SSL/x509 device authentication type only. Define proper setting or leave it NULL. If you not provide the offline storage it will set the default settings as per defined above. It may harm your device by storing the large data. Once memory get full may chance to stop the execution.
"""


SdkOptions={
	"certificate" : { 
        # Certs
        "SSLKeyPath"  : "c:/Users/ankit.sangani/Downloads/reInvent-certificates/cert_reInvent demo.crt",    #aws=pk_devicename.pem   ||   #az=device.key
        "SSLCertPath" : "c:/Users/ankit.sangani/Downloads/reInvent-certificates/pk_reInvent demo.pem",    #aws=cert_devicename.crt ||   #az=device.pem
        "SSLCaPath"   : "c:/SW-AnkitSangani/AWS/sdk/AmazonrootCA.pem"     #aws=root-CA.pem         ||   #az=rootCA.pem
	},
    "offlineStorage":{
        "disabled": False,
	    "availSpaceInMb": 0.01,
	    "fileCount": 5,
        "keepalive":60
    },
     "skipValidation":False,
    # "devicePrimaryKey":"<<DevicePrimaryKey>>",
	# As per your Environment(Azure or Azure EU or AWS) uncomment single URL and commnet("#") rest of URLs.
    # "discoveryUrl":"https://eudiscovery.iotconnect.io" #Azure EU environment 
    "discoveryUrl":"https://discovery.iotconnect.io", #Azure All Environment 
    "IsDebug": True,
    "cpid" : "mssql",
    "sId" : "",
    "env" : "preqa",
    "pf"  : "aws",

    #if device has video stream capability
    "CameraOptions" : {
        "deviceport" : "/dev/video0",
        "video" : {
            "width" : "640",
            "height" : "480",
            "framerate" : "30/1"
        }
    }

}





"""
 * Type    : Callback Function "DeviceCallback()"
 * Usage   : Firmware will receive commands from cloud. You can manage your business logic as per received command.
 * Input   :  
 * Output  : Receive device command, firmware command and other device initialize error response 
"""

def DeviceCallback(msg):
    global Sdk
    print("Firmware :: --- Command Message Received in Firmware ---")
    print("Firmware :: " + json.dumps(msg))
    cmdType = None
    if msg != None and len(msg.items()) != 0:
        cmdType = msg["ct"] if "ct"in msg else None
    # Other Command
    if cmdType == 0:
        """
        * Type    : Public Method "sendAck()"
        * Usage   : Send device command received acknowledgment to cloud
        * 
        * - status Type
        *     st = 6; // Device command Ack status 
        *     st = 4; // Failed Ack
        * - Message Type
        *     msgType = 5; // for "0x01" device command 
        """
        data=msg
        if data != None:
            if "ack" in data and data["ack"]:
                if "id" in data:
                    Sdk.sendAckCmd(data["ack"],2,"sucessfull",data["id"])  #Executed (Cloud Only) = 0, 	Failed = 1, Executed Ack = 2
                else:
                    Sdk.sendAckCmd(data["ack"],2,"sucessfull") #Executed (Cloud Only) = 0, 	Failed = 1, Executed Ack = 2
    else:
        print("Firmware :: rule command",msg)

    # Firmware Upgrade
def DeviceFirmwareCallback(msg):
    global Sdk,device_list
    print("Firmware :: --- firmware Command Message Received ---")
    print("Firmware :: " + json.dumps(msg))
    cmdType = None
    if msg != None and len(msg.items()) != 0:
        cmdType = msg["ct"] if msg["ct"] != None else None

    if cmdType == 1:
        """
        * Type    : Public Method "sendAck()"
        * Usage   : Send firmware command received acknowledgement to cloud
        * - status Type
        *     st = 7; // firmware OTA command Ack status 
        *     st = 4; // Failed Ack
        * - Message Type
        *     msgType = 11; // for "0x02" Firmware command
        """
        data = msg
        if data != None:
            if ("urls" in data) and data["urls"]:
                for url_list in data["urls"]:
                    if "tg" in url_list:
                        for i in device_list:
                            if "tg" in i and (i["tg"] == url_list["tg"]):
                                Sdk.sendOTAAckCmd(data["ack"],5,"sucessfull",i["id"]) #Success=5, Executed (Cloud Only)=0, Failed = 1, Executed/DownloadingInProgress=2, Executed/DownloadDone=3, Failed/DownloadFailed=4
                    else:
                        Sdk.sendOTAAckCmd(data["ack"],5,"sucessfull") #Success=5, Executed (Cloud Only)=0, Failed = 1, Executed/DownloadingInProgress=2, Executed/DownloadDone=3, Failed/DownloadFailed=4

def DeviceConectionCallback(msg):
    cmdType = None
    if msg != None and len(msg.items()) != 0:
        cmdType = msg["ct"] if msg["ct"] != None else None
    #connection status
    if cmdType == 116:
        #Device connection status e.g. data["command"] = true(connected) or false(disconnected)
        print("Firmware :: " + json.dumps(msg))

"""
 * Type    : Public Method "UpdateTwin()"
 * Usage   : Update the twin reported property
 * Input   : Desired property "key" and Desired property "value"
 * Output  : 
"""
# key = "<< Desired property key >>"; // Desired proeprty key received from Twin callback message
# value = "<< Desired Property value >>"; // Value of respective desired property
# Sdk.UpdateTwin(key,value)

"""
 * Type    : Callback Function "TwinUpdateCallback()"
 * Usage   : Manage twin properties as per business logic to update the twin reported property
 * Input   : 
 * Output  : Receive twin Desired and twin Reported properties
"""
def TwinUpdateCallback(msg):
    global Sdk
    if msg:
        print("Firmware :: --- Twin Message Received ---")
        print("Firmware :: " + json.dumps(msg))
        if ("desired" in msg) and ("reported" not in msg):
            for j in msg["desired"]:
                if ("version" not in j) and ("uniqueId" not in j):
                    Sdk.UpdateTwin(j,msg["desired"][j])

"""
 * Type    : Public data Method "SendData()"
 * Usage   : To publish the data on cloud D2C 
 * Input   : Predefined data object 
 * Output  : 
"""
def sendBackToSDK(sdk, dataArray):
    if(sdk.SendData(dataArray) == True):
        print("Firmware :: Data Publish Success")
    else:
        print("Firmware :: Data Publish Fail")
    time.sleep(interval)

def DirectMethodCallback(msg,methodname,rId):
    global Sdk,ACKdirect
    print("Firmware :: " + str(msg))
    print("Firmware :: " +  str(methodname))
    print("Firmware :: " +  str(rId))
    # ACKdirect.append({"data":data,"status":200,"reqId":rId})
    Sdk.DirectMethodACK(msg,200,rId)

def DeviceChangCallback(msg):
    print("Firmware :: " + msg)

def InitCallback(response):
    print("Firmware :: " + response)

def delete_child_callback(msg):
    print("Firmware :: " + msg)
    
def create_child_callback(msg):
    print("Firmware :: " + msg)

def attributeDetails(data):
    print("Firmware :: attribute received in firmware")
    print("Firmware :: " + data)

def onReady(data):
    print("Firmware :: Attribute got Sync ::")
    print("Firmware :: " + str(data))
    global readyStatus
    readyStatus = True


def main():
    global SdkOptions,Sdk,ACKdirect,device_list,CameraOptions
    
    try:
        """
        if SdkOptions["certificate"]:
            for prop in SdkOptions["certificate"]:
                if os.path.isfile(SdkOptions["certificate"][prop]):
                    pass
                else:
                    print("Firmware :: please give proper path")
                    break
        else:
            print("Firmware :: you are not use auth type CA sign or self CA sign ") 
        """    
        """
        * Type    : Object Initialization "IoTConnectSDK()"
        * Usage   : To Initialize SDK and Device cinnection
        * Input   : cpId, uniqueId, sdkOptions, env as explained above and DeviceCallback and TwinUpdateCallback is callback functions
        * Output  : Callback methods for device command and twin properties
        """

        with IoTConnectSDK(UniqueId,SdkOptions,DeviceConectionCallback) as Sdk:
            try:
                """
                * Type    : Public Method "GetAllTwins()"
                * Usage   : Send request to get all the twin properties Desired and Reported
                * Input   : 
                * Output  : 
                """
                    
                device_list=Sdk.Getdevice()
                Sdk.onDeviceCommand(DeviceCallback)
                Sdk.onTwinChangeCommand(TwinUpdateCallback)
                Sdk.onOTACommand(DeviceFirmwareCallback)
                Sdk.onDeviceChangeCommand(DeviceChangCallback)
                Sdk.getTwins()
                Sdk.onReady(onReady)

                for method in directmethodlist:
                    Sdk.regiter_directmethod_callback(method,DirectMethodCallback)

                device_list=Sdk.Getdevice()
                #Sdk.delete_child("childid",delete_child_callback)
                #Sdk.createChildDevice("childid", "childtag", "childid", create_child_callback)
                #Sdk.UpdateTwin("ss01","mmm")
                #sdk.GetAllTwins()
                # Sdk.GetAttributes(attributeDetails)



                while True:
                    #Sdk.GetAttributes()
                    """
                    * Add your device attributes and respective value here as per standard format defined in sdk documentation
                    * "time" : Date format should be as defined //"2021-01-24T10:06:17.857Z"
                    * "data" : JSON data type format // {"temperature": 15.55, "gyroscope" : { 'x' : -1.2 }}
                    """

                    # Example 1: Simple data with temperature
                    # data = {
                    #      "temperature":random.randint(50, 90)
                    # }

                    # Example 2: Edge AI data with ARRAY datatype and nested structure
                    # This demonstrates sending array data (clf) with detection results
                    # Note: IoTConnect platform configuration required:
                    # - Parent attribute: "dg" (OBJECT type)
                    # - Child attributes under "dg":
                    #   - "ppl" (INT datatype)
                    #   - "fid" (INT datatype)
                    #   - "clf" (ARRAY datatype, dt=11)
                    data = {
                         "dg": {
                             "ppl": 2,  # People count
                             "fid": 10,  # Frame ID
                             "clf": [  # Classification results array (ARRAY datatype)
                                 {
                                     "tracker_id": 7,
                                     "class": "person",
                                     "confidence": 0.96
                                 },
                                 {
                                     "tracker_id": 8,
                                     "class": "person",
                                     "confidence": 0.96
                                 }
                             ]
                         }
                    }

                    dObj = [{
                    "uniqueId": UniqueId,
                    "time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                    "data": data
                    }]

                    # """
                    # * Gateway device input data format Example:
                    # """
                    
                    
                    # dObj = [ {
                    #              "uniqueId":"UniqueId",
                    #              "time":datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                    #              "data": {
                    #                      "temperature":random.randint(30, 50)
                    #                      }
                    #              },
                    #              {
                    #                 "uniqueId":"childUniqueId",
                    #                 "time":datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                    #                 "data": {
                    #                      "temperature":random.randint(30, 50)
                    #                      }
                    #                },
                    #              {
                    #                 "uniqueId":"childUniqueId",
                    #                 "time":datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                    #                 "data": {
                    #                      "temperature":random.randint(30, 50)
                    #                      }
                    #                }
                    #             ]

                    #dataArray.append(dObj)
                    #print (dObj)      
                    if(readyStatus == True):
                        print("Firmware :: readyStatus == True")
                        sendBackToSDK(Sdk, dObj)
                    else:
                        print("Firmware :: readyStatus == False")

                    time.sleep(10)

                '''
                Client Disconnect Method
                '''
                Sdk.Dispose()

                time.sleep(10)
                    
            except KeyboardInterrupt:
                print ("Keyboard Interrupt Exception")
                # os.execl(sys.executable, sys.executable, *sys.argv)
                # os.abort()
                sys.exit(0)
                
                
    except Exception as ex:
        print(ex)
        # sys.exit(0)

if __name__ == "__main__":
    main()
